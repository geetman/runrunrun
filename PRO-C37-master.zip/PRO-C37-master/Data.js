class Data {
    constructor(){
        this.drawing=null
    }
}